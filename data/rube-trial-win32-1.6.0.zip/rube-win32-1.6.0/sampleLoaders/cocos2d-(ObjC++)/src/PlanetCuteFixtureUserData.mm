//  Author: Chris Campbell - www.iforce2d.net
//  -----------------------------------------
//
//  PlanetCuteFixtureUserData
//
//  See header file for description.
//

#import "PlanetCuteFixtureUserData.h"

@implementation PlanetCuteFixtureUserData

@end
