//  Author: Chris Campbell - www.iforce2d.net
//  -----------------------------------------
//
//  DestroyBodyLayer
//
//  Just to demonstrate removing bodies from the world. The only thing
//  different to the superclass is the ccTouchesBegan method.
//

#import "RUBELayer.h"

@interface DestroyBodyLayer : RUBELayer

@end
