//  Author: Chris Campbell - www.iforce2d.net
//  -----------------------------------------
//
//  only for this demo project, you can remove this in your own app
//

#import "cocos2d.h"

@interface ExamplesMenuLayer : CCLayer {

}

+(CCScene *) scene;

@end
