//Name: Add body
//Tags: body

//add a body with no name at the current cursor position

addBody(-1, '{"type":"dynamic","awake":true}').setPos( cursor() );
