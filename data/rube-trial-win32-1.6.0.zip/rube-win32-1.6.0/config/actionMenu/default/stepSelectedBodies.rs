//Name: Step selected bodies
//Tags: physics, step, simulation
//Runs the physics simulation for the selected bodies only.

step( sb(), queryNumericValue("Number of steps:", 60) );
